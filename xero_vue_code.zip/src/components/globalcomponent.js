export default{
    sidebars:false,
    is_loading:false
}