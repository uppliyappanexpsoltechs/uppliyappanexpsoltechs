module.exports={
    decodedIdToken:'',
    tokenSet:'',
    decodedAccessToken:'',
    accessTokenExpires:'',
    allTenants:'',
    activeTenant:'',
}