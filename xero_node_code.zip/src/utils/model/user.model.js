// module.export=
export default (sequelize, Sequelize) => {
	const User = sequelize.define('users', {
		username: {
			type: Sequelize.STRING
		},
		password: {
			type: Sequelize.STRING
		},
		id_token: {
			type: Sequelize.STRING
		},
		access_token: {
			type: Sequelize.STRING
		},
		token_type: {
			type: Sequelize.STRING
		},
		refresh_token: {
			type: Sequelize.STRING
		},
		scope: {
			type: Sequelize.STRING
		},
		activeTenant: {
			type: Sequelize.STRING
		},
		session_state:{
			type: Sequelize.STRING
		},
		expires_at:{
			type: Sequelize.STRING
		}
	});
	return User;
}
