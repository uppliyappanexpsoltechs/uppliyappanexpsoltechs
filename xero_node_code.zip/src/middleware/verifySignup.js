import db from '../utils/config/db.config';
const User = db.user;
const verifySignup = (req, res, next) => {
	// -> Check Username is already in use
	User.findOne({
		where: {
			username: req.body.username
		}
	}).then(user => {
		if(user){
            let response={
                status:'failure',
                data:'Username is already taken'
            }
			res.send(response);
			return;
		}
        next();
	});
    
}
const signUp = {};
signUp.verifySignup = verifySignup;
export default signUp;