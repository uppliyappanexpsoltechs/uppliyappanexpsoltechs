import { XeroClient, Contact } from 'xero-node';
import express from 'express'
const client_id = process.env.CLIENT_ID;
const client_secret = process.env.CLIENT_SECRET;
const redirectUrl = process.env.REDIRECT_URI;
import db from '../utils/config/db.config';
const User = db.user;
import jwtDecode from 'jwt-decode';
import fetch from "node-fetch";
import bcrypt from 'bcrypt';
var LocalStorage = require('node-localstorage').LocalStorage,
localStorage = new LocalStorage('./scratch');
import { createConnection } from 'mysql';
const session = require("express-session");
var FileStore = require('session-file-store')(session);
const scopes = "offline_access openid profile email accounting.transactions accounting.transactions.read accounting.reports.read accounting.journals.read accounting.settings accounting.settings.read accounting.contacts accounting.contacts.read accounting.attachments accounting.attachments.read files files.read assets assets.read projects projects.read payroll.employees payroll.payruns payroll.payslip payroll.timesheets payroll.settings";
// const express = require('express');
const app = express();
const fileStoreOptions = {}
const xero = new XeroClient({
    clientId: client_id,
    clientSecret: client_secret,
    redirectUris: [redirectUrl],
    scopes: scopes.split(" "),
    state: "imaParam=look-at-me-go",
    httpTimeout: 2000
});
let pool = createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    multipleStatements: true,
    port: 3306
});
const verifyToken=function(req,res,next){
    const Localstorage=JSON.parse(localStorage.getItem('key'))
    xero.setTokenSet(Localstorage)
    const Tokenset=xero.readTokenSet()
    console.log(Tokenset.expired());
    if(true){
        // res.send('Token Expired')
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.redirect('http://localhost:8080/login')
    }
    next();
}
const Token = {};
Token.verifyToken = verifyToken;
export default Token;