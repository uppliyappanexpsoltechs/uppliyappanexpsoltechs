require("dotenv").config();
import { json, urlencoded } from "body-parser";
import crypto from 'crypto';
import express, { json as _json, urlencoded as _urlencoded } from "express";
import cors from "cors";
import session from "express-session";
import { Request, Response } from "express";
import xeroroute from "./router/router";
const app = express();
import cookieParser from 'cookie-parser';
app.use(_json());
app.use(_urlencoded({ extended: false }));
app.use(json());
app.use(cors());
app.use(cookieParser());
app.use(urlencoded({ extended: true }))
app.use(function (req, res, next) {
    // req.session.firstname='uppli'
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Origin,Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers,Authorization");
    next();
});
// app.use(session({ resave: true ,secret: '123456' , saveUninitialized: true,cookie: { maxAge: 24*12*12 ,secure:false}}));
app.use(session({ resave: true ,secret: '123456' , saveUninitialized: true}));
app.use('/xero', xeroroute);

export default app;