import express from "express";
import session from "express-session";
const app = express();
const cookieParser = require('cookie-parser');
app.use(cookieParser());
app.use(session({
    resave: false,
    key: 'sessionid',
    secret: process.env.SECRET,
    saveUninitialized: false,
    cookie: {
        domain: '.localhost',
        path: '/',
        maxAge: 12 * 60 * 60,
        httpOnly: true,
        sameSite: false,
        secure: false
    }
}));
app.use((req, res, next) => {
    // console.log('asd===>>>>',req.session.id)
    req.session.isAuth=true
    if (req.session.firstname == '') {
        req.session.firstname = ''
    }
    next();
});
export default app;